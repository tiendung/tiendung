from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import random
from openai import OpenAI
from datetime import datetime
import json
import os

# Constants
MAX_CONTEXT_MESSAGES = 50
CONTEXT_FILE = "conversation_context.json"
IGNORED_MESSAGES = ["👍", "😄", "ok", "ừ", "uhm", "uh", "à"]
CONTACT_NAME = "AI Tech"
CONTACT_TYPE = "group"
CONTACT_ITEM_SELECTOR = f"div[id^='{CONTACT_TYPE}-item-']"

# OpenAI Configuration
client = OpenAI(api_key='<api-key>')

# Chrome Configuration
chrome_options = Options()
chrome_options.add_experimental_option("debuggerAddress", "127.0.0.1:9222")
driver = webdriver.Chrome(options=chrome_options)

# Random responses
random_responses = [
    "Ừ, tôi hiểu điều đó",
    "Thật thú vị!",
    "Tôi đồng ý với bạn",
    "Haha, nghe vui đấy",
    "Để tôi suy nghĩ về điều đó",
    "Ồ, thật sao?",
    "Tôi cũng nghĩ vậy",
    "Điều đó thật tuyệt"
]

class ConversationManager:
    def __init__(self):
        self.context = self.load_context()
        
    def load_context(self):
        try:
            if os.path.exists(CONTEXT_FILE):
                with open(CONTEXT_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    today = datetime.now().strftime("%Y-%m-%d")
                    return data.get(today, [])
            return []
        except Exception as e:
            print(f"Lỗi khi load context: {str(e)}")
            return []

    def save_context(self):
        try:
            today = datetime.now().strftime("%Y-%m-%d")
            data = {today: self.context}
            
            with open(CONTEXT_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Lỗi khi save context: {str(e)}")

    def add_message(self, role, content, time_str=""):
        if self.should_ignore_message(content):
            return
            
        message = {
            "role": role,
            "content": content,
            "time": time_str,
            "timestamp": datetime.now().isoformat()
        }
        
        self.context.append(message)
        
        if len(self.context) > MAX_CONTEXT_MESSAGES:
            self.context = self.context[-MAX_CONTEXT_MESSAGES:]
            
        self.save_context()

    def should_ignore_message(self, content):
        content = content.strip().lower()
        return (
            content in IGNORED_MESSAGES or
            len(content) < 2 or
            content.startswith("http") or
            all(c in "😀😁😂🤣😃😄😅😆😉😊" for c in content)
        )

    def get_context_for_openai(self):
        messages = [
            {
                "role": "system",
                "content": """Bạn tên là Quế, bạn là trợ lý ảo của nhóm AI Tech. 
                Trong nhóm có bạn và 3 thành viên gồm: Anh Linh, em Phương và em Hoàng Tùng. 
                Bạn sẵn sàng trả lời bất kỳ câu hỏi gì một cách thân thiện với các thành viên trong nhóm.
                Khi được mention bằng @bot, bạn sẽ tập trung xử lý yêu cầu cụ thể của người dùng.
                Bạn luôn trả lời bằng Tiếng Việt một cách ngắn gọn, súc tích nhưng đầy đủ thông tin.
                """
            }
        ]
        
        for msg in self.context:
            messages.append({
                "role": msg["role"],
                "content": msg["content"]
            })
            
        return messages

# Initialize conversation manager
conversation_manager = ConversationManager()

def process_mention_message(message_text):
    message_text = message_text.strip()
    # Kiểm tra nếu tin nhắn bắt đầu bằng @
    if message_text.startswith('@'):
        # Loại bỏ @ ở đầu và trả về nội dung tin nhắn
        return message_text[1:].strip()
    return None

def get_today_messages():
    try:
        blocks = WebDriverWait(driver, 2).until(
            EC.presence_of_all_elements_located((By.CLASS_NAME, "block-date"))
        )
        
        for block in blocks:
            try:
                date_spans = block.find_elements(By.CSS_SELECTOR, "span.content span")
                is_today = False
                for span in date_spans:
                    if span.text.strip() == "Hôm nay":
                        is_today = True
                        break
                        
                if not is_today:
                    continue
                
                chat_items = block.find_elements(By.CLASS_NAME, "chat-item")
                
                for chat_item in chat_items:
                    try:
                        is_me = 'me' in chat_item.get_attribute('class')
                        
                        try:
                            text_element = chat_item.find_element(By.CSS_SELECTOR, ".text-message__container .text")
                            message_text = text_element.text.strip()
                        except:
                            continue
                            
                        try:
                            time_element = chat_item.find_element(By.CSS_SELECTOR, ".card-send-time__sendTime")
                            message_time = time_element.text.strip()
                        except:
                            message_time = ""
                            
                        if message_text:
                            conversation_manager.add_message(
                                'assistant' if is_me else 'user',
                                message_text,
                                message_time
                            )
                            
                    except Exception as e:
                        print(f"Lỗi xử lý tin nhắn: {str(e)}")
                        continue
                        
            except Exception as e:
                print(f"Lỗi xử lý block: {str(e)}")
                continue
                
        return conversation_manager.get_context_for_openai()
        
    except Exception as e:
        print(f"Lỗi lấy tin nhắn: {str(e)}")
        return []

def get_openai_response(message):
    try:
        conversation_manager.add_message('user', message)
        messages = conversation_manager.get_context_for_openai()
        
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=messages,
            max_tokens=150,
            temperature=0.7
        )
        
        ai_response = response.choices[0].message.content.strip()
        conversation_manager.add_message('assistant', ai_response)
        return ai_response
        
    except Exception as e:
        print(f"Lỗi khi gọi OpenAI API: {str(e)}")
        return None

def ensure_correct_contact():
    try:
        try:
            rich_input = WebDriverWait(driver, 2).until(
                EC.presence_of_element_located((By.ID, "richInput"))
            )
            if rich_input.get_attribute("placeholder") and CONTACT_NAME in rich_input.get_attribute("placeholder"):
                return True
        except:
            pass

        print("Đang tìm lại contact...")
        search_box = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.ID, "contact-search-input"))
        )
        search_box.clear()
        search_box.send_keys(CONTACT_NAME)
        time.sleep(2)
        
        friend_items = WebDriverWait(driver, 5).until(
            EC.presence_of_all_elements_located((By.CSS_SELECTOR, CONTACT_ITEM_SELECTOR))
        )
        
        if friend_items:
            friend_items[0].click()
            time.sleep(2)
            return True
        return False

    except Exception as e:
        print(f"Lỗi khi kiểm tra contact: {str(e)}")
        return False

def get_last_message():
    try:
        # Lấy block tin nhắn cuối cùng
        latest_block = WebDriverWait(driver, 2).until(
            EC.presence_of_all_elements_located((By.CLASS_NAME, "block-date"))
        )[-1]
        
        # Lấy tin nhắn cuối cùng trong block
        messages = latest_block.find_elements(By.CLASS_NAME, "chat-item")
        if not messages:
            return None
            
        for message in reversed(messages):
            try:
                text_element = message.find_element(By.CSS_SELECTOR, ".text-message__container .text")
                time_element = message.find_element(By.CSS_SELECTOR, ".card-send-time__sendTime")
                message_text = text_element.text.strip()
                
                # Nếu là tin nhắn của bot thì chỉ xử lý khi có @ ở đầu
                if 'me' in message.get_attribute('class') and not message_text.startswith('@'):
                    continue
                    
                return {
                    'text': message_text,
                    'time': time_element.text.strip()
                }
            except:
                continue
                
        return None
        
    except Exception as e:
        print(f"Lỗi khi lấy tin nhắn cuối: {str(e)}")
        return None

def send_message(message):
    try:
        if not ensure_correct_contact():
            return False
            
        js_code = """
        var div = document.getElementById('input_line_0');
        div.focus();
        div.textContent = arguments[0];
        
        var inputEvent = new Event('input', {
            bubbles: true,
            cancelable: true,
        });
        div.dispatchEvent(inputEvent);
        
        var enterEvent = new KeyboardEvent('keydown', {
            key: 'Enter',
            code: 'Enter',
            keyCode: 13,
            which: 13,
            bubbles: true
        });
        div.dispatchEvent(enterEvent);
        """
        
        driver.execute_script(js_code, message)
        time.sleep(1)
        return True
            
    except Exception as e:
        print(f"Lỗi khi gửi tin nhắn: {str(e)}")
        return False

# Main execution
try:
    driver.get("https://chat.zalo.me/")
    time.sleep(2)
    
    if not ensure_correct_contact():
        raise Exception("Không thể kết nối với contact")
    
    print("Bot đã sẵn sàng!")
    last_message_data = None
    use_openai = True
    
    while True:
        try:
            current_message_data = get_last_message()
            
            if current_message_data and (
                last_message_data is None or
                current_message_data['text'] != last_message_data['text'] or
                current_message_data['time'] != last_message_data['time']
            ):
                message_text = current_message_data['text']
                print(f"\nTin nhắn mới: {message_text}")
                print(f"Thời gian: {current_message_data['time']}")
                
                mention_message = process_mention_message(message_text)
                
                if mention_message:
                    print(f"Phát hiện lệnh @bot: {mention_message}")
                    response = get_openai_response(mention_message)
                else:
                    response = get_openai_response(message_text) if use_openai else random.choice(random_responses)
                
                if response:
                    print(f"Trả lời: {response}")
                    if send_message(response):
                        last_message_data = current_message_data
                
            time.sleep(5)
            
        except Exception as e:
            print(f"Lỗi trong vòng lặp: {str(e)}")
            time.sleep(5)

except KeyboardInterrupt:
    print("\nĐã dừng bot")
except Exception as e:
    print(f"Lỗi: {str(e)}")
finally:
    print("Kết thúc chương trình")